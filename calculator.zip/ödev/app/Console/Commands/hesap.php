<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class hesap extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'hesap {value}  {islem}  {value2} ';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Hesap Makinesi';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
     
    {
       $islem=$this->argument('islem');
       $value=$this->argument('value');
       $value2= $this->argument('value2');

    if(is_numeric($value) && is_numeric($value2) ){

      if ($islem == '+'){
            
            $sonuc =$value + $value2;

            $this->info('sonuc = '.$sonuc);
            }

        elseif ($islem == '-' ){

             $sonuc =$value - $value2;
     
            $this->info('sonuc = '.$sonuc);
            }

        elseif ($islem == '*' ){

            $sonuc =$value * $value2;
        
            $this->info( 'sonuc = '.$sonuc);
            }  

        elseif ($islem == '/' ){
 
            if($value=='0' && $value2=='0'){

                $this->info('0/0 belirsizlik durumu');
             }

             elseif($value2 == '0'){
                $this->info('Sıfırla bölme islemi tanimsiz');
             }
            
            else{

            $sonuc =$value / $value2;
            
            $this->info('sonuc = '.$sonuc);
             }
        } 
        
        else{
            
            $this->info('geçersiz karakter girişi');
        }
      }  
     else{
        $this->info('girdiğiniz deger sayi degil, Lütfen sayi giriniz');
     }
    }
   
}
